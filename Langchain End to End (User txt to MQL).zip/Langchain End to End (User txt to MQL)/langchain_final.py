import os
import json
import graphviz
import transformers
import pandas as pd
import pymongo
import openai
from pymongo import MongoClient
from langchain.document_loaders.csv_loader import CSVLoader
from langchain import HuggingFaceHub
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from langchain.chains import LLMChain
from pymongo_schema.extract import extract_pymongo_client_schema
from langchain.llms import OpenAI
from langchain.prompts.few_shot import FewShotPromptTemplate
from langchain.prompts.prompt import PromptTemplate
from langchain.embeddings import OpenAIEmbeddings
from langchain.document_loaders import JSONLoader

# Import ALl the models

# embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
os.environ["HUGGINGFACEHUB_API_TOKEN"] = "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"
openai.api_key = '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'
os.environ['OPENAI_API_KEY'] = "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"
# embeddings = OpenAIEmbeddings(model_name="ada", headers={"Authorization": openai.api_key})
embeddings = OpenAIEmbeddings(
    model="text-embedding-ada-002"
)
llm = OpenAI(temperature=0.3)
# llm = HuggingFaceHub(repo_id="google/flan-t5-large")
# model = transformers.AutoModelForSeq2SeqLM.\
#     from_pretrained("human-centered-summarization/financial-summarization-pegasus")
# tokenizer = transformers.PegasusTokenizer.\
#     from_pretrained("human-centered-summarization/financial-summarization-pegasus")
# summarizer = pipeline("summarization", model=model, tokenizer=tokenizer)


# Read the Data from the JSON file
with open("filegpt.json", "r") as f:
  data = json.load(f)


# Initialize the global variables
global documents, documents1, path
path = []


def check_key(data):
    """
    This function return the keys(only top level) of the input json
    :param data: Input JSON
    :return: keys as List
    """
    keys = []
    for skey in data.keys():
        keys.append(skey)
    # print(keys)
    return keys


# Create the Graph using graphviz library
u = graphviz.Digraph('unix', filename='Output_tree',
                     node_attr={'color': 'lightblue2', 'style': 'filled'})
u.attr(size='12,12')


def add_path(cpath, data):
    """
    This function create the Tree structure from the Input JSON file.
    Also Add the edges in the graphviz graph created Before.
    :param cpath: current path of the Tree
    :param data: JSON data
    :return: Null
    """
    global path
    for key in data.keys():
        scpath = cpath + [key]
        # Add edge to the Graph
        u.edge(cpath[-1], key)
        if type(data[key]) not in [str, list, int]:
            add_path(scpath, data[key])
        elif type(data[key]) is list:
            for iteam in data[key]:
                if type(iteam) not in [str, list, int]:
                    add_path(scpath, iteam)
            pass
        else:
            path.append(scpath)

# u.view()
# print(u.source)
# print(path)
# print(data[0]['socialMediaHandles']['webTrafficReporting'])


def print_mongoschema(client):
    """
    This function is used to get schema of client
    :param client: MongoDB client
    :return: schema
    """
    with pymongo.MongoClient() as client:
        schema = extract_pymongo_client_schema(client)
    print(schema)
    return schema


def qurey_mangodb(collection, qurey):
    """
    This function is for query MongoDB
    :param collection: MongoDB collection
    :param qurey: User qurey
    :return: result doc
    """
    # Find all documents
    results = collection.find(qurey)
    return results


def call_mongodb(qurey):
    """
    This function is for Initialized MongoDB
    :param qurey: User qurey
    :return: result doc
    """
    # client = MongoClient()
    client = MongoClient('localhost', 27017)
    print_mongoschema(client)
    db = client.mydatabase
    collection = db.top_doc
    return qurey_mangodb(collection, qurey)


def preprocess_doc(data):
    """
    This function is used for preprocess Document and get ready for VectorDB
    :param data: input data
    :return: Document
    """
    global documents
    # Convert the data into Pandas DataFrame
    df = pd.DataFrame(data)
    # del df['_id']
    # df = df.drop_duplicates()
    # for post in collection.find():
    #   pprint.pprint(post)
    df.to_csv("Data_update.csv", index=False)
    df_loader = CSVLoader(file_path='Data_update.csv')
    documents = df_loader.load()
    # print(documents)


def find_similar_data(query):
    """
    This function return the top four doc similar with user query
    :param query: User Query
    :return: Top matching Doc
    """
    preprocess_doc(data)
    # create the vectorestore to use as the index
    db = FAISS.from_documents(documents, embeddings)
    cdocs = db.similarity_search(query)
    # print(docs[1].page_content)
    return cdocs


def preprocess_path(path):
    """
    This function is used for preprocess Tree path and get ready for VectorDB
    :param path: input path
    :return: Document
    """
    global documents1
    path_df = pd.DataFrame(path)
    path_df.to_csv("path_df.csv", index=False)
    loader = CSVLoader(file_path='path_df.csv')
    documents1 = loader.load()


# print(data[10])
add_path(['data'], data[0])
# u.view()
# print(u.source)
# print("\n\nTree Paths :", path)
preprocess_path(path)


def find_final_prompt_text(query):
    """
    This function match user query with top matching doc and top tree path
    :param query: input user query
    :return: Final_prompt_text (langchain prompt variable)
    """
    global path
    top_doc = []
    top_tree_path = []
    Final_prompt_text = ""

    docs=find_similar_data(query)
    for index in range(len(docs)):
        # print("\nDOC Index " + str(index) + " :")
        # print("\nMetaData :", docs[index].metadata)
        # print(docs[index].page_content.split('\n'))
        dictionary = {}
        for item in docs[index].page_content.split('\n'):
            if len(item.split(': ')) == 2:
                key, value = item.split(': ')
                dictionary[key] = value
            else:
                key = item.split(': ')[0]
                value = ': '.join(item.split(': ')[1:]).replace("'", '"').replace('"{', "'{").replace('}"', "}'")
                dictionary[key] = json.loads(value)
        jsonStr = json.dumps(dictionary)
        # print(jsonStr)
        top_doc.append(json.loads(jsonStr))


    db1 = FAISS.from_documents(documents1, embeddings)
    # query = "give me website of sitel?"
    docs1 = db1.similarity_search(query)
    # print("\nQuery :", query, "\n")
    # print("\n \nSearch Result (0 to 3 Tree Height) :\n", docs1[0].page_content)

    for index in range(len(docs1)):
        # print("\nDOC Index " + str(index) + " :")
        # print("\nMetaData :", docs[index].metadata)
        # print(docs1[index].page_content.split('\n'))
        # current_path = [x.split(": ")[1] for x in docs1[index].page_content.split('\n')]
        # my_json = {','.join(docs1[index].page_content.split('\n'))}
        dictionary = {}
        for item in docs1[index].page_content.split('\n'):
            if len(item.split(': ')) == 2:
                key, value = item.split(': ')
                if value != '':
                    dictionary[key] = value
        jsonStr = json.dumps(dictionary)
        # print(jsonStr)
        top_tree_path.append(json.loads(jsonStr))


    # print('\n', top_doc)
    # print('\n', top_tree_path)
    prompt_text = ["['companyName']"]
    for path in top_tree_path:
        prompt = ""
        for key in path:
            if key != '0':
                prompt = prompt + "['" + path[key] + "']"
        prompt_text.append(prompt)
        # print(prompt)

        # print(eval(prompt))

    # print(top_doc[0]['website'])

    print("\nFinal_prompt_text:")
    for index in range(len(top_doc)):
        # print("\nIteam "+str(index)+" :\n")
        Final_prompt_text = Final_prompt_text + "\n\nIteam "+str(index)+" :\n"
        for prompt in prompt_text:
            try:
                # print("top_doc" + str([index]) + prompt)
                result = eval("top_doc"+str([index])+prompt)
                Final_prompt_text = Final_prompt_text + "\ntop_doc" + str([index]) + prompt + " = " + str(result)
                # print("top_doc" + str([index]) + prompt + " = ", result)
            except:
                Final_prompt_text = Final_prompt_text + "\ntop_doc" + str([index]) + prompt
    print(Final_prompt_text)
    return Final_prompt_text


# find_final_prompt_text("give me the company name having more than 500 employee ?")


def few_short():
    """
    This take few example task try to generate same task for given input(Many input required)
    :return: Null
    """
    examples = [
      {
        "input": "give me geo location of WNS Global Services?",
        "output": "db.top_doc.find(!companyName: WNS Global Services !!, !revenue: 1!!)"
      },
      {
        "input": "what are the service providers used by GlobalMed Inc.?",
        "output": "db.top_doc.find(!companyName: GlobalMed Inc.!!, !marketingSpendTechStack: 1!!)"
      }
    ]

    example_prompt = PromptTemplate(input_variables=["input", "output"], template="Human text: {input}\nMQL query: {output}")

    print(example_prompt.format(**examples[0]))
    # .replace("!", "{").replace("!!", "}")
    prompt = FewShotPromptTemplate(
        examples=examples,
        example_prompt=example_prompt,
        suffix="Human text: {text}",
        input_variables=["text"]
    )

    print(prompt.format(text="give me number of employees working in WNS Global Services?"))


# Prompt for MQL Generation
template_text = """
    Suppose 'top_doc' is a MongoDB collection
    As the custom data is large the data tree is created for the custom data. The path of the tree is recorded.
    -> Denote edge of the tree
    MongoDB statement 1 : top_doc[0]["companyName"]
    Tree path for above MongoDB statement 1 : top_doc -> companyName
    MongoDB statement 2 : top_doc[0]['hqlocation']['city']
    Tree path for above MongoDB statement 2 : top_doc -> hqlocation -> city
    Then best path which is related to human query is also selected and given in the Final_prompt_text.

    Now, consider yourself as a bot that returns MQL corresponding to specific human readable query.
    You must consider only the Final_prompt_text structure to returns MQL.
    You must consider only the Final_prompt_text variable names to returns MQL.
    The user may ask you complex queries where you have to create MQL.
    And you only return MQL and nothing else !!!!
    Important Constrain: Strict to the variable names with in Final_prompt_text for MQL

    # Training Phase
    query: "give me hqlocation geo location of GlobalMed Inc.?"
    Final_prompt_text: "
    Iteam 0 :
    top_doc[0]['companyName'] =  GlobalMed Inc.
    top_doc[0]['countries'] =  ['United States', 'United Kingdom', 'Australia', 'Singapore']
    top_doc[0]['hqlocation']['city'] =  Phoenix
    top_doc[0]['hqlocation']['area'] =  dummy
    top_doc[0]['marketingSpendTechStack']['serviceProviderUse'] =  ['Digital Marketing Agency', 'Telehealth Platform Provider']

    Iteam 1 :
    top_doc[1]['companyName'] =  WNS Global Services
    top_doc[1]['countries'] =  []
    top_doc[1]['hqlocation']['city'] =  Mumbai
    top_doc[1]['hqlocation']['area'] =  India
    top_doc[1]['marketingSpendTechStack']['serviceProviderUse'] =  ['IBM,Microsoft']
    "
    MQL statement : db.top_doc.find(!-companyName-: -WNS Global Services- !!, !-hqlocation-: 1!!)

    # Testing Phase
    query = {query}
    Final_prompt_text: {Final_prompt_text}
    MQL statement :
    """

# Initialized PromptTemplate with Final_prompt_text and query variables
prompt = PromptTemplate(
    input_variables=["Final_prompt_text", "query"],
    template=template_text,
)

# Create langchain using llm and prompt
chain = LLMChain(llm=llm, prompt=prompt)


def call_langchain(query):
    """
    This function user generate MQL from the user query
    :param query: User query input
    :return: MQL
    """
    # query = "give me number of employees working in WNS Global Services?"
    Final_prompt_text = find_final_prompt_text(query)
    # query = query + "\n Important Constrain: Strict to the variable names with in Final_prompt_text for MQL"
    MQL = (chain.run({
        # 'text': query
        'query': query,
        'Final_prompt_text': Final_prompt_text
        }).replace("!!", "}").replace("!", "{").replace("-", "'"))
    print("\nquery : ", query)
    print("MQL :", MQL.strip())
    return MQL
    # client = MongoClient('mongodb://localhost:27017/') # connect to your cluster
    # db = client.mydatabase # get a database
    # result = eval(MQL.strip())
    # for doc in result: # loop over the cursor
    #     print(doc) # print each document


# query = "give me number of employees working in WNS Global Services?"
# query = "how many employees working in WNS Global Services?"
# query = "give me geo location of Genpact?"
# query = "how many patent ABB have ?"
# query = "what are the service providers used by GlobalMed Inc.?"
# query = "give me the company's having more than 500 employee ?"
# query = "which company have the highest number of employee ?"
# query = "What is stock price of sitel?"
# query = "I want to know about Teleperformance"
# query = "What is the marketing spend of Concentrix?"
query = "list out the awards get by PQR"
call_langchain(query)

