import uvicorn
import json
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from langchain_final import call_langchain
from fastapi.middleware.cors import CORSMiddleware
"""
    This python main.py file is used to establish the API connection 
    and do the inference for User text to MQL(MongoDB Query Language).
"""
# Create Fast API
app = FastAPI()
# Add the CORS middleware to your app
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Allow any origin
    allow_credentials=True, # Allow cookies
    allow_methods=["*"], # Allow any method
    allow_headers=["*"], # Allow any header
)


@app.post("/langchain")
def handle_request(request_data: dict):
    """
    :param request_data: Get query from Front-End
    :return: MQL as JSON response
    """
    print("req data", request_data)
    prompt = request_data.get("prompt")
    print("Received message from the client:", prompt)
    question = prompt
    MQL = call_langchain(question)
    response = {"text": MQL}
    return JSONResponse(response)


if __name__ == "__main__":
    # Run the API
    uvicorn.run(app, host="127.0.0.2", port=8000)
